window.onload = function() {
    function outside(x) {

        function inside() {
            alert(++x);
        }

        return inside;
    }

    var returned = outside(2);
    returned();
};