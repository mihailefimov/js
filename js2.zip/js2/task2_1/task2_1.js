var slider = {};

slider.init = function(id) {
    var element = document.getElementById(id);
    return element;
};

slider.add = function(alt) {
    var img = '<img src=' + alt + '/>';
    var element = this.init("slider");
    var imgElement = document.createElement('img');
    imgElement.src = alt;
    element.appendChild(imgElement);
};


window.onload = function() {
    slider.add('cat.jpg');
};

