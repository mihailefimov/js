function sumDigits() {
    var number = document.getElementById("input").value;
    var sum = calcSum(parseInt(number));
    alert(sum);
}

function calcSum(number) {
    var remainder = number % 10;
    var sum = remainder;
    if(number >= 10) {
        var rest = Math.floor(number / 10);
        sum += calcSum(rest);
    }
    return sum;
}
