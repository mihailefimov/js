function calc(a, b, operator) {
    if (typeof a === 'string') {
        a = parseInt(a);
    }
    if (typeof b === 'string') {
        b = parseInt(b);
    }
    switch (operator) {
        case "+":
            return a + b;
        case "-":
            return a - b;
        case "*":
            return a * b;
        case "/":
            if (b === 0) {
                console.log('Error: zero division');
                return;
            }
            return a / b;
        default:
            console.log('Wrong operator. Use +, -, *, /');
            return;
    }
}


console.log(calc(4, 5, '+'));
console.log(calc("4", "5", '+'));
console.log(calc(3, 2, '-'));
console.log(calc('3', 2, '*'));
console.log(calc(4, 2, '/'));
console.log(calc(10, 0, '/'));

