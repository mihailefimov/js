window.onload = function() {
    var handlers = {};
    handlers.startDraw = function() {
        console.log("startDraw");
    };

    handlers.endDraw = function() {
        console.log("endDraw");
    };

    handlers.drawing = function() {
        console.log("drawing");
    };

    handlers.erase = function() {
        console.log("erase");
    };

    var canvasElem = document.getElementsByTagName("canvas")[0];

    canvasElem.addEventListener('mousedown', function() {
        handlers.startDraw();
    });

    canvasElem.addEventListener('mouseup', function() {
        handlers.endDraw();
    });

    canvasElem.addEventListener('mouseout', function() {
        handlers.endDraw();
    });

    canvasElem.addEventListener('mousemove', function() {
        handlers.drawing();
    });
};