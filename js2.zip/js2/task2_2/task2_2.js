function copyOnFly(event) {
    var elem = document.getElementsByClassName("input1")[0];
    var textarea = document.getElementsByClassName("textarea1")[0];
    textarea.value = elem.value;
}