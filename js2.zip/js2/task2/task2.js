document.addEventListener("DOMContentLoaded", readyDOM);
function readyDOM() {
    alert('DOM загружен. Обработчик DOMContentLoaded сработал');
}

function onloadElement() {
    alert('Обработчик onload сработал')
}

window.onbeforeunload = function(e) {
    return "You may lose the changes!!!\n are you sure???";
};